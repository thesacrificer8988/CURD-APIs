package com.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.entity.student;
import com.service.StudentService;

@RestController
public class AdminController {
	
	@Autowired
	StudentService studentService;
	
	
	@PostMapping(value = "storeStudent",consumes = MediaType.APPLICATION_JSON_VALUE)
	public String storeStudent(@RequestBody student s) {
		return studentService.AddStudent(s);
	}
	
	@DeleteMapping(value = "deleteStudent/{sid}")
	public String deleteStudent(@PathVariable("sid") int sid) {
		return studentService.deleteStudent(sid);
	}
	
	@PutMapping(value = "updateStuddent",consumes = MediaType.APPLICATION_JSON_VALUE)
	public String updateProduct(@RequestBody student s) {
		return studentService.updateProductDetails(s);
	}
	
	@GetMapping(value = "findAllStudentsDetails")
	public List<student> findAllStudentsDetails() {
		return studentService.findAllStudentsDetails();
	}
}
