package com.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.repository.StudentRepository;
import com.repository.StudentmarksRepository;
import com.entity.student;
import com.entity.studentmarks;

@Service
public class StudentService {

	@Autowired
	StudentRepository studentRepository;
	
	@Autowired
	StudentmarksRepository studentmarksRepository;

	public String AddStudent(student s) {
		Optional<student> op = studentRepository.findById(s.getSid());
		if(op.isPresent()) {
			return "Student id already available..";
		}else {
			studentmarks marks = s.getMarks();
			int Totalmarks = marks.getEng()+marks.getMarathi()+marks.getMath()+marks.getScience()+marks.getSocial();
			marks.setTotalmarks(Totalmarks);
			if(marks.getTotalmarks()<=100) {
				marks.setGrade("F");
			}else if(marks.getTotalmarks()>100 && marks.getTotalmarks()<=200) {
				marks.setGrade("D");
			}else if(marks.getTotalmarks()>200 && marks.getTotalmarks()<=300) {
				marks.setGrade("C");
			}else if(marks.getTotalmarks()>300 && marks.getTotalmarks()<=400) {
				marks.setGrade("B");
			}else if(marks.getTotalmarks()>400 && marks.getTotalmarks()<=500) {
				marks.setGrade("A");
			}
			studentRepository.save(s);
			return "Student details saved succesfully..!";
		}
	}

	public String deleteStudent(int sid) {
		Optional<student> op = studentRepository.findById(sid);
		if(op.isPresent()) {
			student s = op.get();
			studentRepository.delete(s);
			return "Student deleted...";
		}else {
			return "Student not exists";
		}
	}

	public String updateProductDetails(student s1) {
		Optional<student> op = studentRepository.findById(s1.getSid());
		if(op.isPresent()) {
			student s = op.get();
			s.setSid(s1.getSid());
			s.setAge(s1.getAge());
			s.setMarks(s1.getMarks());
			s.setSclass(s1.getSclass());
			s.setSection(s1.getSection());
			s.setSname(s1.getSname());
			studentRepository.saveAndFlush(s);
			return "Product details updated successfully";
		}else {
			return "Product not exists";
		}
	}

	public List<student> findAllStudentsDetails(){
		return studentRepository.findAll();
	}

	public student findStudentById(int sid) {
		Optional<student> op = studentRepository.findById(sid);
		if(op.isPresent()) {
			student s = op.get();
			return s;
		}else {
			return null;
		}
	}

	public studentmarks showMarksDetails(int sid) {
		Optional<student> op = studentRepository.findById(sid);
		if(op.isPresent()) {
			student s = op.get();
			studentmarks marks = s.getMarks();
			return marks;
		}else {
			return null;
		}
	}

	public String updateMarksDetails(studentmarks marks) {
		Optional<studentmarks> op = studentmarksRepository.findById(marks.getMid());
		if(op.isPresent()) {
			studentmarks sm = op.get();
			sm.setEng(marks.getEng());
			sm.setGrade(marks.getGrade());
			sm.setMarathi(marks.getMarathi());
			sm.setMath(marks.getMath());
			sm.setScience(marks.getScience());
			sm.setSocial(marks.getSocial());
			sm.setTotalmarks(marks.getTotalmarks());
			sm.setMid(marks.getMid());
			studentmarksRepository.saveAndFlush(sm);
			return "StudentMarks details updated successfully";
		}else {
			return "Student does not exists";
		}
	}
	
	
	
	
}
