package com.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class studentmarks {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int mid;
	private int math;
	private int eng;
	private int marathi;
	private int social;
	private int science;
	private int totalmarks;
	private String grade;
	
	public int getMid() {
		return mid;
	}
	public void setMid(int mid) {
		this.mid = mid;
	}
	public int getMath() {
		return math;
	}
	public void setMath(int math) {
		this.math = math;
	}
	public int getEng() {
		return eng;
	}
	public void setEng(int eng) {
		this.eng = eng;
	}
	public int getMarathi() {
		return marathi;
	}
	public void setMarathi(int marathi) {
		this.marathi = marathi;
	}
	public int getSocial() {
		return social;
	}
	public void setSocial(int social) {
		this.social = social;
	}
	public int getScience() {
		return science;
	}
	public void setScience(int science) {
		this.science = science;
	}
	public int getTotalmarks() {
		return totalmarks;
	}
	public void setTotalmarks(int totalmarks) {
		this.totalmarks = totalmarks;
	}
	public String getGrade() {
		return grade;
	}
	public void setGrade(String grade) {
		this.grade = grade;
	}
	public studentmarks(int mid, int math, int eng, int marathi, int social, int science, int totalmarks,
			String grade) {
		super();
		this.mid = mid;
		this.math = math;
		this.eng = eng;
		this.marathi = marathi;
		this.social = social;
		this.science = science;
		this.totalmarks = totalmarks;
		this.grade = grade;
	}
	public studentmarks() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "studentmarks [mid=" + mid + ", math=" + math + ", eng=" + eng + ", marathi=" + marathi + ", social="
				+ social + ", science=" + science + ", totalmarks=" + totalmarks + ", grade=" + grade + "]";
	}
	
	
}
